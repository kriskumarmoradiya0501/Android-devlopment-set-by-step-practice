package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val buttonskills = findViewById<Button>(R.id.btnSkills)

        buttonskills.setOnClickListener{
            intent = Intent(this,skills_Activity::class.java)
            startActivity(intent)
        }

        val buttoneducation = findViewById<Button>(R.id.btnEducation)

        buttoneducation.setOnClickListener{
            intent = Intent(this, education_activity::class.java)
            startActivity(intent)
        }

        val buttonwork = findViewById<Button>(R.id.btnWork)

        buttonwork.setOnClickListener{
            intent = Intent(this, work_activity::class.java)
            startActivity(intent)
        }

        val buttonarchivment = findViewById<Button>(R.id.btnArchivments)

        buttonarchivment.setOnClickListener{
            intent = Intent(this, archivment_activity::class.java)
            startActivity(intent)
        }
    }
}