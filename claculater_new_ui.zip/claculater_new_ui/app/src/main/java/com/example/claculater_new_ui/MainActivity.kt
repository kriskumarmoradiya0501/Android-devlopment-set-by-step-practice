package com.example.claculater_new_ui

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var input = ""
    private var firstOperand = ""
    private var secondOperand = ""
    private var operation = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val resultView = findViewById<TextView>(R.id.textView)

        // Handle number buttons and dot
        val numberButtons = listOf(
            findViewById<Button>(R.id.btn0),
            findViewById<Button>(R.id.btn1),
            findViewById<Button>(R.id.btn2),
            findViewById<Button>(R.id.btn3),
            findViewById<Button>(R.id.btn4),
            findViewById<Button>(R.id.btn5),
            findViewById<Button>(R.id.btn6),
            findViewById<Button>(R.id.btn7),
            findViewById<Button>(R.id.btn8),
            findViewById<Button>(R.id.btn9),
            findViewById<Button>(R.id.btnDot)
        )

        numberButtons.forEach { button ->
            button.setOnClickListener {
                input += button.text
                resultView.text = input
            }
        }

        // Handle operation buttons
        val operationButtons = mapOf(
            R.id.btnPlus to "+",
            R.id.btnMinus to "-",
            R.id.btnMultiplication to "*",
            R.id.btnDivision to "/"
        )

        operationButtons.forEach { (id, op) ->
            findViewById<Button>(id).setOnClickListener {
                if (input.isNotEmpty()) {
                    firstOperand = input
                    operation = op
                    input = ""
                }
            }
        }

        // Handle equals button
        findViewById<Button>(R.id.btnEquals).setOnClickListener {
            if (input.isNotEmpty() && operation.isNotEmpty()) {
                secondOperand = input
                val result = calculateResult(firstOperand, secondOperand, operation)
                resultView.text = result
                input = ""
                firstOperand = ""
                secondOperand = ""
                operation = ""
            }
        }

        // Handle clear button
        findViewById<Button>(R.id.btnAC).setOnClickListener {
            input = ""
            firstOperand = ""
            secondOperand = ""
            operation = ""
            resultView.text = "0"
        }
    }

    private fun calculateResult(first: String, second: String, op: String): String {
        val num1 = first.toDoubleOrNull()
        val num2 = second.toDoubleOrNull()

        if (num1 == null || num2 == null) return "Error"

        return when (op) {
            "+" -> (num1 + num2).toString()
            "-" -> (num1 - num2).toString()
            "*" -> (num1 * num2).toString()
            "/" -> if (num2 != 0.0) (num1 / num2).toString() else "Error"
            else -> "Error"
        }
    }
}
