package com.example.calculaterapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val buttonplus = findViewById<Button>(R.id.btnPlus)
        val buttonmul = findViewById<Button>(R.id.btnMultiplication)
        val buttonmin = findViewById<Button>(R.id.btnMinus)
        val buttondiv = findViewById<Button>(R.id.btnDivision)
        val ti1 = findViewById<TextInputEditText>(R.id.ti1)
        val ti2 = findViewById<TextInputEditText>(R.id.ti2)
        val resultView = findViewById<TextView>(R.id.textView3)


        buttonplus.setOnClickListener{
            val num1 = ti1.text.toString().toDouble()
            val num2 = ti2.text.toString().toDouble()

            val result = num1 + num2
            resultView.text = "Result: $result"

        }

        buttonmin.setOnClickListener{
            val num1 = ti1.text.toString().toDouble()
            val num2 = ti2.text.toString().toDouble()

            val result = num1 - num2
            resultView.text = "Result: $result"

        }

        buttonmul.setOnClickListener{
            val num1 = ti1.text.toString().toDouble()
            val num2 = ti2.text.toString().toDouble()

            val result = num1 * num2
            resultView.text = "Result: $result"

        }

        buttondiv.setOnClickListener{
            val num1 = ti1.text.toString().toDouble()
            val num2 = ti2.text.toString().toDouble()

            val result = num1 / num2
            resultView.text = "Result: $result"

        }
    }
}